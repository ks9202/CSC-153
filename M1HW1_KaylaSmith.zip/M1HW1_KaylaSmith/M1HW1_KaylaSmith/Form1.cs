﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 1/22/2023
* CSC 153
* Kayla Smith
* This program asks a user to input their first name, middle name, last name, and title.
* The program has buttons a user can choose from to display their name in various formats.
*/

namespace M1HW1_KaylaSmith
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void titleFirstMiddleLastButton_Click(object sender, EventArgs e)
        {
            // On click, displays a message box with the user's name formatted as "Title First Middle Last"
            MessageBox.Show($"{titleTextBox.Text} {firstNameTextBox.Text} {middleNameTextBox.Text} {lastNameTextBox.Text}");
        }

        private void firstMiddleLastButton_Click(object sender, EventArgs e)
        {
            // On click, displays a message box with the user's name formatted as "First Middle Last"
            MessageBox.Show($"{firstNameTextBox.Text} {middleNameTextBox.Text} {lastNameTextBox.Text}");
        }

        private void firstLastButton_Click(object sender, EventArgs e)
        {
            // On click, displays a message box with the user's name formatted as "First Last"
            MessageBox.Show($"{firstNameTextBox.Text} {lastNameTextBox.Text}");
        }

        private void lastFirstMiddleTitleButton_Click(object sender, EventArgs e)
        {
            // On click, displays a message box with the user's name formatted as "Last, First Middle, Title"
            MessageBox.Show($"{lastNameTextBox.Text}, {firstNameTextBox.Text} {middleNameTextBox.Text}, {titleTextBox.Text}");
        }

        private void lastFirstMiddleButton_Click(object sender, EventArgs e)
        {
            // On click, displays a message box with the user's name formatted as "Last, First Middle"
            MessageBox.Show($"{lastNameTextBox.Text}, {firstNameTextBox.Text} {middleNameTextBox.Text}");
        }

        private void lastFirstButton_Click(object sender, EventArgs e)
        {
            // On click, displays a message box with the user's name formatted as "Last, First"
            MessageBox.Show($"{lastNameTextBox.Text}, {firstNameTextBox.Text}");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // On click, clears all text boxes.
            titleTextBox.Clear();
            firstNameTextBox.Clear();
            middleNameTextBox.Clear();
            lastNameTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // On click, closes the window.
            this.Close();
        }
    }
}
