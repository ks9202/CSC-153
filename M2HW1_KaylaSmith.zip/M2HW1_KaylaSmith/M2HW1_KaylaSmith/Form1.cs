﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW1_KaylaSmith
{
    /**
    * 2/12/2023
    * CSC 153
    * Kayla Smith
    * This is a form that prompts the user to select two primary colors, then displays
    * the result of those two colors combined as the form's backround when the
    * Mix button is clicked. When the same color is selected twice, the form background
    * will change to the selected color.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void mixButton_Click(object sender, EventArgs e)
        {
            // Top level of if-else structure checks for the first color selected.
            if (redRadioButton1.Checked)
            {
                // Sub level of if-else structure checks for the second color selected
                // and outputs the appropriate color as the form's background.
                if (redRadioButton2.Checked)
                {
                    this.BackColor = Color.Red;
                }
                else if (yellowRadioButton2.Checked)
                {
                    this.BackColor = Color.Orange;
                }
                else if (blueRadioButton2.Checked)
                {
                    this.BackColor = Color.Purple;
                }
                else
                {
                    MessageBox.Show("Please select two colors to mix.");
                }
            }
            else if (yellowRadioButton1.Checked)
            {
                if (redRadioButton2.Checked)
                {
                    this.BackColor = Color.Orange;
                }
                else if (yellowRadioButton2.Checked)
                {
                    this.BackColor = Color.Yellow;
                }
                else if (blueRadioButton2.Checked)
                {
                    this.BackColor = Color.Green;
                }
                else
                {
                    MessageBox.Show("Please select two colors to mix.");
                }
            }
            else if (blueRadioButton1.Checked)
            {
                if (redRadioButton2.Checked)
                {
                    this.BackColor = Color.Purple;
                }
                else if (yellowRadioButton2.Checked)
                {
                    this.BackColor = Color.Green;
                }
                else if (blueRadioButton2.Checked)
                {
                    this.BackColor = Color.Blue;
                }
                else
                {
                    MessageBox.Show("Please select two colors to mix.");
                }
            }
            else
            {
                MessageBox.Show("Please select two colors to mix.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits the form.
            this.Close();
        }
    }
}
