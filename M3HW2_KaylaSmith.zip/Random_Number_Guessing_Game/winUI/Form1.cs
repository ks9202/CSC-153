﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace winUI
{
    /**
    * 3/5/2023
    * CSC 153
    * Kayla Smith
    * This form generates a random number between 1 and 100 and prompts
    * a user to guess the number. If the number guessed is higher or lower
    * than the random number it will inform the user. If the correct random
    * number is guessed it will be regenerated and the game will restart.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            // Creating the file the random number is stored in and
            // generating the random number.
            InitializeComponent();
            Random r = new Random();
            StreamWriter write;
            write = File.CreateText("random.txt");
            write.WriteLine(r.Next(1, 101));
            write.Close();
        }

        private void guessButton_Click(object sender, EventArgs e)
        {
            // Accessing the random number and reading the user's guess.
            StreamReader read;
            StreamWriter write;
            Random r = new Random();
            read = File.OpenText("random.txt");
            int num = 0, guess;

            // Reads the last random number generated.
            while (read.EndOfStream == false)
            {
                num = int.Parse(read.ReadLine());
            }
            read.Close();
            
            // Try catch for input validation.
            try
            {
                guess = int.Parse(guessTextBox.Text);

                // Structure to output whether the user's guess is too high,
                // too low, or correct. If the guess is correct, the random
                // number is regenerated.
                if (guess > num)
                {
                    MessageBox.Show("Too high, try again.");
                    guessTextBox.Clear();
                    guessTextBox.Focus();
                }
                else if (guess < num)
                {
                    MessageBox.Show("Too low, try again.");
                    guessTextBox.Clear();
                    guessTextBox.Focus();
                }
                else
                {
                    MessageBox.Show("Congratulations! You guessed correctly!\n" +
                        "A new number will be generated.");
                    guessTextBox.Clear();
                    guessTextBox.Focus();

                    write = File.AppendText("random.txt");
                    write.WriteLine(r.Next(1, 101));
                    write.Close();
                }
            }
            catch
            {
                MessageBox.Show("Please enter a valid number.");
                guessTextBox.Clear();
                guessTextBox.Focus();
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits the form.
            this.Close();
        }
    }
}
