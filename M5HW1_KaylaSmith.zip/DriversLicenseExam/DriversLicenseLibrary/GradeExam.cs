﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DriversLicenseLibrary
{
    public static class GradeExam
    {
        public static char[] ReadAnswers(string fileName)
        {
            // Reads user's answers from a file
            // Expected format all caps, each answer letter on a new line
            char[] userAnswers = new char[20];
            StreamReader read;
            read = File.OpenText(fileName);
            for (int i = 0; i < userAnswers.Length; i++)
            {
                userAnswers[i] = Char.Parse(read.ReadLine());
            }
            read.Close();
            return userAnswers;
        }

        public static List<int> ReturnIncorrect(char[] userAnswers)
        {
            // Answer key initialization and incorrect nums list declaration
            char[] answerKey = {'B','D','A','A','C',
                                'A','B','A','C','D',
                                'B','C','D','A','D',
                                'C','C','B','D','A'};
            List<int> incorrectNums = new List<int>();

            // If an answer is incorrect, adds question number to list
            // Returns list of incorrect question numbers
            for (int i = 0; i < userAnswers.Length; i++)
            {
                if (userAnswers[i] != answerKey[i])
                {
                    incorrectNums.Add(i + 1);
                }
            }
            return incorrectNums;
        }

        public static bool GradePass(List<int> incorrectNums)
        {
            // Returns true if the exam is passed, false if failed
            bool pass = true;
            if (incorrectNums.Count > 5)
            {
                pass = false;
            }
            return pass;
        }

        public static string OutputIncorrect(List<int> incorrectNums)
        {
            // Prepares question nums of incorrect questions for output
            string incorrectOutput = "";
            for (int i = 0; i < incorrectNums.Count; i++)
            {
                incorrectOutput += incorrectNums[i] + " ";
            }
            return incorrectOutput;
        }
    }
}
