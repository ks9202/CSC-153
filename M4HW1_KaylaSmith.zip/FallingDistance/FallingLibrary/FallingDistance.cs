﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FallingLibrary
{
    public class Calculate
    {
        // Calculates falling distance.
        public static double FallingDistance(double seconds, double gravity = 9.8)
        {
            return (((seconds * seconds) * gravity) * 0.5);
        }
    }
}
