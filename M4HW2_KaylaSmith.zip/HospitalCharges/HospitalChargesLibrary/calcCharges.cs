﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalChargesLibrary
{
    public class calcCharges
    {
        public static double CalcStayCharges(int userDays, double baseFee = 350.00)
        {
            // Calculates stay charges
            return userDays * baseFee;
        }

        public static double CalcMiscCharges(double medsCost, double surgeryCost, double labCost, double rehabCost)
        {
            // Calculates misc charges
            return medsCost + surgeryCost + labCost + rehabCost;
        }

        public static double CalcTotalCharges(double stayCharges, double miscCharges)
        {
            // Calculates total cost
            return stayCharges + miscCharges;
        }
    }
}
