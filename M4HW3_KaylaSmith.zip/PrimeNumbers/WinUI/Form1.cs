﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrimeLibrary;

namespace WinUI
{
    /**
    * 3/30/2023
    * CSC 153
    * Kayla Smith
    * This form takes a user's input of an integer and displays in a messsage box
    * whether the entry is prime.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Try catch to validate input.
            try
            {
                // Parse and declare prime boolean.
                int num = int.Parse(numTextBox.Text);
                bool prime;

                // Calculates whether num is prime.
                prime = PrimeCalc.IsPrime(num);

                // Output
                if (prime == true)
                {
                    MessageBox.Show(num + " is prime.");
                }
                else
                {
                    MessageBox.Show(num + " is not prime.");
                }
            }
            catch
            {
                // Invalid input.
                MessageBox.Show("Invalid entry. Please enter a whole number.");
            }

            numTextBox.Clear();
            numTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form.
            this.Close();
        }
    }
}
