﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_SmithKayla
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            /**
            * 1/29/2023
            * CSC 153
            * Kayla Smith
            * 
            * A program that calculates the cost of a paint job accounting for
            * labor and paint expenses. The user inputs the size of the wall and 
            * cost of paint per gallon, and this program outputs the number of
            * required gallons of paint, hours of labor, paint cost, labor cost,
            * and total cost in a message box.
            */

            InitializeComponent();
        }
        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear text boxes
            sqFeetTextBox.Clear();
            pricePerGallonTextBox.Clear();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Variables for square feet, price per gallon, number of gallons, paint cost,
            // labor hours, labor cost, and total cost.
            double sqFeet = double.Parse(sqFeetTextBox.Text);
            double pricePerGallon = double.Parse(pricePerGallonTextBox.Text);
            int numGallons, laborHours;
            double paintCost, laborCost, totalCost;

            // If else structure to determine the number of gallons of paint needed.
            // Explicit conversion does not affect accuracy of the calculation. 
            if (sqFeet <= 115)
            {
                numGallons = 1;
            }
            else if (sqFeet % 115 == 0)
            {
                numGallons = (int)(sqFeet / 115);
            }
            else
            {
                numGallons = (int)(sqFeet % 115) + 1;
            }

            // Calculates cost of paint
            paintCost = numGallons * pricePerGallon;

            // If else structure to determine the hours of labor needed.
            // Explicit conversion does not affect the accuracy of the calculation.
            if (sqFeet <= 14.375)
            {
                laborHours = 1; 
            }
            else if (sqFeet % 14.375 == 0)
            {
                laborHours = (int)(sqFeet / 14.375);
            }
            else
            {
                laborHours = (int)(sqFeet / 14.375) + 1;
            }

            // Calculates labor cost
            laborCost = laborHours * 20.00;

            // Calculates total cost
            totalCost = laborCost + paintCost;

            // Output to message box
            MessageBox.Show
                (
                    $"Required gallons of paint: {numGallons}" +
                    $"\nRequired hours of labor: {laborHours}" +
                    $"\nPaint cost: ${paintCost}" +
                    $"\nLabor cost: ${laborCost}" +
                    $"\nTotal cost: ${totalCost}"
                );
        }
    }
}
