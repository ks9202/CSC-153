﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields
        private string _name, _idNum, _department, _position;

        // Constructor for name, id, department, position
        public Employee(string name, string idNum, string department, string position)
        {
            _name = name;
            _idNum = idNum;
            _department = department;
            _position = position;
        }

        // Constructor for name and id
        public Employee(string name, string idNum)
        {
            _name = name;
            _idNum = idNum;
            _department = "";
            _position = "";
        }

        // Empty constructor
        public Employee()
        {
            _name = "";
            _idNum = "";
            _department = "";
            _position = "";
        }

        public string Name
        {
            get;
            set;
        }

        public string IdNum
        {
            get;
            set;
        }

        public string Department
        {
            get;
            set;
        }

        public string Position
        {
            get;
            set;
        }
    }
}
