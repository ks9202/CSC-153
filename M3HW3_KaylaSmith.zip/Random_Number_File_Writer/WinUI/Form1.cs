﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI
{
    /**
    * 3/11/2023
    * CSC 153
    * Kayla Smith
    * This form asks a user for an amount of random numbers to generate.
    * The numbers are recorded in an output file that the user is prompted
    * to save.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            int numRandom;

            // Try catch for input validation.
            try
            {
                numRandom = int.Parse(numTextBox.Text);

                // If-else structure for further input validation.
                if (numRandom < 0 || numRandom > 99)
                {
                    MessageBox.Show("Enter a number from 1 to 99.");
                }
                else
                {
                    StreamWriter write;
                    Random rand = new Random();

                    // If-else checks if the user has saved the output file.

                    if (saveFile.ShowDialog() == DialogResult.OK)
                    {
                        // Creates and saves output file.
                        write = File.CreateText(saveFile.FileName);

                        // Writes random numbers to file.
                        for (int i = 0; i < numRandom; i++)
                        {
                            write.WriteLine(rand.Next(1, 101));
                        }
                        write.Close();

                        MessageBox.Show("File saved successfully.");
                    }
                    else
                    {
                        MessageBox.Show("File not saved.");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Enter a valid number to generate.");
            }

            numTextBox.Clear();
            numTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form.
            this.Close();
        }
    }
}
