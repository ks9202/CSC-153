﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WorldSeriesLibrary
{
    public class WorldSeries
    {
        public static List<string> ReadTeams()
        {
            // Reads contents of Teams.txt into teamsList and returns teamsList
            List<string> teamsList = new List<string>();
            using (StreamReader read = new StreamReader("Teams.txt"))
            {
                while (!read.EndOfStream)
                {
                    teamsList.Add(read.ReadLine());
                }
            }
            return teamsList;
        }

        public static List<string> ReadWins()
        {
            // Reads contents of WorldSeriesWinners.txt into winsList and returns winsList
            List<string> winsList = new List<string>();
            using (StreamReader read = new StreamReader("WorldSeriesWinners.txt"))
            {
                while (!read.EndOfStream)
                {
                    winsList.Add(read.ReadLine());
                }
            }
            return winsList;
        }

        public static int ReturnWins(List<string> winsList, string choice)
        {
            // Accepts winsList and a user's team choice to return the number of wins a team has
            int wins = 0;
            for (int i = 0; i < winsList.Count; i++)
            {
                if (choice.Equals(winsList[i]))
                {
                    wins++;
                }
            }
            return wins;
        }
    }
}
