﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using DriversLicenseLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        /**
        * 4/17/2023
        * CSC 153
        * Kayla Smith
        * This form accepts a user's input file of exam question answers.
        * The form will grade according to an answer key and output whether
        * the user has passed or failed, how many questions were answered
        * correctly, how many were answered incorrectly, and the question
        * numbers of any incorrect questions.
        */
        public Form1()
        {
            InitializeComponent();
        }

        public void openFileButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // Declare user answers array, incorrect nums list
                    char[] userAnswers = new char[20];
                    List<int> incorrectNums = new List<int>();
                    // Read answers from file
                    userAnswers = GradeExam.ReadAnswers(openFileDialog.FileName.ToString());
                    // Returns list of incorrect question nums
                    incorrectNums = GradeExam.ReturnIncorrect(userAnswers);

                    // Output pass or fail, num of correct/incorrect questions
                    bool pass = GradeExam.GradePass(incorrectNums);
                    if (pass == true)
                    {
                        MessageBox.Show("Exam passed.\n"
                                        + (20 - incorrectNums.Count) + " correct.\n"
                                        + incorrectNums.Count + " incorrect.\n"
                                        + "Choose OK to continue.");
                    }
                    else
                    {
                        MessageBox.Show("Exam failed.\n"
                                        + (20 - incorrectNums.Count) + " correct.\n"
                                        + incorrectNums.Count + " incorrect.\n"
                                        + "Choose OK to continue.");
                    }

                    // Output incorrect question nums
                    if (incorrectNums.Count == 0)
                    {
                        MessageBox.Show("No incorrect questions. Congratulations!");
                    }
                    else
                    {
                        MessageBox.Show("Incorrect question numbers: " + GradeExam.OutputIncorrect(incorrectNums));
                    }
                }
                catch
                {
                    // Invalid file submitted
                    MessageBox.Show("Please submit a valid file");
                }
            }
            else
            {
                // No file submitted
                MessageBox.Show("Please submit a file.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form
            this.Close();
        }
    }
}
