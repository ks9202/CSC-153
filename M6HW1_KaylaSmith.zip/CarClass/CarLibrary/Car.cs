﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarLibrary
{
    public class Car
    {
        // Fields
        private string _year;
        private string _make;
        private int _speed = 0;

        // Default constructor
        public Car()
        {

        }

        // Constructor
        public Car(string year, string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
        }

        public string Year
        {
            get;
            set;
        }

        public string Make
        {
            get;
            set;
        }

        public int Speed
        {
            get;
            set;
        }

        public void Accelerate()
        {
            // Increases speed by 5
            Speed += 5;
        }

        public void Brake()
        {
            // Checks that speed isn't at zero
            // If not at zero, car will decrease speed by 5
            if (Speed > 0)
            {
                Speed -= 5;
            }
        }
    }
}
