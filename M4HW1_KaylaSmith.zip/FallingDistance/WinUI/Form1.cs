﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FallingLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        /**
        * 3/22/2023
        * CSC 153
        * Kayla Smith
        * This form accepts a user's input of seconds and outputs
        * the distance an object would fall in that many seconds.
        */
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Try catch for input validation.
            try
            {
                // Gather seconds from text box and parse.
                double seconds = int.Parse(secondsTextBox.Text);
                // Pass seconds into FallingDistance to calculate distance,
                // assign to distance.
                double distance = Calculate.FallingDistance(seconds);

                // Output
                MessageBox.Show(distance + " meters");
            }
            catch
            {
                MessageBox.Show("Please enter a valid number.");
            }

            secondsTextBox.Clear();
            secondsTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form
            this.Close();
        }
    }
}
