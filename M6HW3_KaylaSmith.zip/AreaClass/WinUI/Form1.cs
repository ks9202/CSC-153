﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AreaLibrary;

namespace WinUI
{
    /**
    * 5/9/23
    * CSC 153
    * Kayla Smith
    * This is a form that will calculate the area of a circle, rectangle, or 
    * cylinder using overloaded methods in the Area class.
    */
    public partial class Form1 : Form
    {
        double PI = Math.PI;

        public Form1()
        {
            InitializeComponent();
        }

        private void circleButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Input
                double radius = Double.Parse(circleRadiusTextBox.Text);
                // Calculate area and display
                MessageBox.Show("Your circle's area is " + Area.CalcArea(radius, PI));
            }
            catch
            {
                // Invalid entry
                MessageBox.Show("Invalid radius. Please enter again.");
            }
            // Clear
            circleRadiusTextBox.Clear();
        }

        private void rectangleButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Input
                int width = int.Parse(widthTextBox.Text);
                int length = int.Parse(lengthTextBox.Text);
                // Calculate area and display
                MessageBox.Show("Your rectangle's area is " + Area.CalcArea(width, length));
            }
            catch
            {
                // Invalid entry
                MessageBox.Show("Entries must be integers. Please enter again.");
            }
            // Clear
            lengthTextBox.Clear();
            widthTextBox.Clear();
        }

        private void cylinderButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Input
                double radius = Double.Parse(cylinderRadiusTextBox.Text);
                double height = Double.Parse(heightTextBox.Text);
                // Calculate area and display
                MessageBox.Show("Your cylinder's area is " + Area.CalcArea(radius, height, PI));
            }
            catch
            {
                // Invalid entry
                MessageBox.Show("One or more invalid entries. Please enter again.");
            }
            // Clear
            cylinderRadiusTextBox.Clear();
            heightTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
