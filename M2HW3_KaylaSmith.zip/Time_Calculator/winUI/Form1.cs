﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winUI
{
    /**
    * 2/25/2023
    * CSC 153
    * Kayla Smith
    * This form displays how many days, hours, minutes, or seconds that a
    * user's input of seconds is equivalent to based on the largest unit of
    * time applicable.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears the seconds text box.
            secondsTextBox.Clear();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            /* Calculates the amount of days, hours, minutes, or seconds
            * that the user input of seconds is equivalent to based on
            * the largest unit of time applicable.
            */

            int userSeconds = 0;
            const int MINUTE = 60;
            const int HOUR = 3600;
            const int DAY = 86400;

            // Ensures user input can be parsed.
            try
            {
                userSeconds = int.Parse(secondsTextBox.Text);

                if (userSeconds >= DAY)
                    // Second level of if else structure corrects
                    // the program's grammar when necessary.
                    if ((userSeconds / DAY) == 1)
                    {
                        MessageBox.Show("1 day.");
                    }
                    else
                    {
                        /* Calculations for number of days.
                        * userSeconds is put into the string variable
                        * userOutput to be displayed in a message box.
                        */
                        userSeconds = (userSeconds / DAY);
                        string userOutput = userSeconds.ToString();
                        MessageBox.Show(userOutput + " days.");
                    }
                else if (userSeconds >= HOUR)
                {
                    if ((userSeconds / HOUR) == 1)
                    {
                        MessageBox.Show("1 hour.");
                    }
                    else
                    {
                        /* Calculations for number of hours.
                        * userSeconds is put into the string variable
                        * userOutput to be displayed in a message box.
                        */
                        userSeconds = (userSeconds / HOUR);
                        string userOutput = userSeconds.ToString();
                        MessageBox.Show(userOutput + " hours.");
                    }
                }
                else if (userSeconds >= MINUTE)
                {
                    if ((userSeconds / MINUTE) == 1)
                    {
                        MessageBox.Show("1 minute.");
                    }
                    else
                    {
                        /* Calculations for number of minutes.
                        * userSeconds is put into the string variable
                        * userOutput to be displayed in a message box.
                        */
                        userSeconds = (userSeconds / MINUTE);
                        string userOutput = userSeconds.ToString();
                        MessageBox.Show(userOutput + " minutes.");
                    }
                }
                else
                {
                    if (userSeconds == 1)
                    {
                        MessageBox.Show("1 second.");
                    }
                    else
                    {
                        /* userSeconds is put into the string variable
                         * userOutput to be displayed in a message box.
                         */
                        string userOutput = userSeconds.ToString();
                        MessageBox.Show(userOutput + " seconds.");
                    }
                }
            }
            catch
            {
                // Displays when user input is not an integer.
                MessageBox.Show("Invalid number of seconds.\n Try again?");
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            // Closes the form.
            this.Close();
        }
    }
}
