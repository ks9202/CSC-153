﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WinUI
{
    /**
    * 3/11/2023
    * CSC 153
    * Kayla Smith
    * This program allows a user to choose a file to read a list of
    * numbers from. The numbers will be displayed in a list box along
    * with a message box containing the total of the numbers and the
    * total amount of numbers read.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openFileButton_Click(object sender, EventArgs e)
        {
            StreamReader read;

            // Checks if the user opens a file.
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                // Try catch to validate file.
                try
                {
                    // Opens file, reads numbers, outputs to list box.
                    // Count and total are used to track numbers read
                    // and total amount respectively.
                    int num, total = 0, count = 0;
                    read = File.OpenText(openFile.FileName);
                    numListBox.Items.Clear();

                    while (!read.EndOfStream)
                    {
                        num = int.Parse(read.ReadLine());
                        total += num;
                        count++;
                        numListBox.Items.Add(num);
                    }
                    read.Close();

                    // Output
                    MessageBox.Show("Total: " + total + "\n" +
                                    "Numbers read: " + count);
                }
                catch
                {
                    MessageBox.Show("Invalid file.");
                }
            }
            else
            {
                MessageBox.Show("Open a file to display numbers.");
            }
        }

        private void clearListButton_Click(object sender, EventArgs e)
        {
            // Clears list items.
            numListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form.
            this.Close();
        }
    }
}
