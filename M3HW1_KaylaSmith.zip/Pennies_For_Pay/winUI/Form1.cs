﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace winUI
{
    /**
    * 3/5/2023
    * CSC 153
    * Kayla Smith
    * This form takes a user's input of days and calculates the pay
    * recieved for that many days of work. Payment starts at a penny
    * per day, and doubles each day afterward.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits the form.
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Try catch to ensure user input can be parsed into userDays.
            try
            {
                // Variables
                int userDays, days = 1;
                double pay = 0.01;
                userDays = int.Parse(daysTextBox.Text);

                // First level of if-else structure verifies that the number
                // of days entered is positive.
                if (userDays <= 0)
                {
                    MessageBox.Show("Please enter a positive number of days.");
                }
                else
                {
                    // Pay calculation.
                    while (days < userDays)
                    {
                        pay = pay * 2;
                        days++;
                    }
                    // Output
                    MessageBox.Show("Pay: " + pay.ToString());
                }
            }
            catch
            {
                MessageBox.Show("Please enter a valid number of days.");
            }
            // Clears text box after output.
            daysTextBox.Clear();
        }
    }
}
