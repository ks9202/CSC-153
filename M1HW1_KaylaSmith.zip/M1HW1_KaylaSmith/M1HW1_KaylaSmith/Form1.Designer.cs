﻿
namespace M1HW1_KaylaSmith
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.titleFirstMiddleLastButton = new System.Windows.Forms.Button();
            this.firstMiddleLastButton = new System.Windows.Forms.Button();
            this.firstLastButton = new System.Windows.Forms.Button();
            this.lastFirstMiddleTitleButton = new System.Windows.Forms.Button();
            this.lastFirstMiddleButton = new System.Windows.Forms.Button();
            this.lastFirstButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "First name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Middle name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Last name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(110, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Title:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.titleTextBox);
            this.groupBox1.Controls.Add(this.lastNameTextBox);
            this.groupBox1.Controls.Add(this.middleNameTextBox);
            this.groupBox1.Controls.Add(this.firstNameTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(76, 26);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(372, 248);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Enter a name to format";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(182, 48);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.firstNameTextBox.TabIndex = 4;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(182, 93);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.middleNameTextBox.TabIndex = 5;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(182, 139);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 26);
            this.lastNameTextBox.TabIndex = 6;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(182, 189);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 26);
            this.titleTextBox.TabIndex = 7;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lastFirstButton);
            this.groupBox2.Controls.Add(this.lastFirstMiddleButton);
            this.groupBox2.Controls.Add(this.lastFirstMiddleTitleButton);
            this.groupBox2.Controls.Add(this.firstLastButton);
            this.groupBox2.Controls.Add(this.firstMiddleLastButton);
            this.groupBox2.Controls.Add(this.titleFirstMiddleLastButton);
            this.groupBox2.Location = new System.Drawing.Point(58, 304);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(406, 213);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Choose a format";
            // 
            // titleFirstMiddleLastButton
            // 
            this.titleFirstMiddleLastButton.Location = new System.Drawing.Point(33, 46);
            this.titleFirstMiddleLastButton.Name = "titleFirstMiddleLastButton";
            this.titleFirstMiddleLastButton.Size = new System.Drawing.Size(158, 32);
            this.titleFirstMiddleLastButton.TabIndex = 0;
            this.titleFirstMiddleLastButton.Text = "Mr. John A Doe";
            this.titleFirstMiddleLastButton.UseVisualStyleBackColor = true;
            this.titleFirstMiddleLastButton.Click += new System.EventHandler(this.titleFirstMiddleLastButton_Click);
            // 
            // firstMiddleLastButton
            // 
            this.firstMiddleLastButton.Location = new System.Drawing.Point(217, 46);
            this.firstMiddleLastButton.Name = "firstMiddleLastButton";
            this.firstMiddleLastButton.Size = new System.Drawing.Size(158, 32);
            this.firstMiddleLastButton.TabIndex = 1;
            this.firstMiddleLastButton.Text = "John A Doe";
            this.firstMiddleLastButton.UseVisualStyleBackColor = true;
            this.firstMiddleLastButton.Click += new System.EventHandler(this.firstMiddleLastButton_Click);
            // 
            // firstLastButton
            // 
            this.firstLastButton.Location = new System.Drawing.Point(33, 97);
            this.firstLastButton.Name = "firstLastButton";
            this.firstLastButton.Size = new System.Drawing.Size(158, 32);
            this.firstLastButton.TabIndex = 2;
            this.firstLastButton.Text = "John Doe";
            this.firstLastButton.UseVisualStyleBackColor = true;
            this.firstLastButton.Click += new System.EventHandler(this.firstLastButton_Click);
            // 
            // lastFirstMiddleTitleButton
            // 
            this.lastFirstMiddleTitleButton.Location = new System.Drawing.Point(217, 97);
            this.lastFirstMiddleTitleButton.Name = "lastFirstMiddleTitleButton";
            this.lastFirstMiddleTitleButton.Size = new System.Drawing.Size(158, 32);
            this.lastFirstMiddleTitleButton.TabIndex = 3;
            this.lastFirstMiddleTitleButton.Text = "Doe, John A, Mr.";
            this.lastFirstMiddleTitleButton.UseVisualStyleBackColor = true;
            this.lastFirstMiddleTitleButton.Click += new System.EventHandler(this.lastFirstMiddleTitleButton_Click);
            // 
            // lastFirstMiddleButton
            // 
            this.lastFirstMiddleButton.Location = new System.Drawing.Point(33, 151);
            this.lastFirstMiddleButton.Name = "lastFirstMiddleButton";
            this.lastFirstMiddleButton.Size = new System.Drawing.Size(158, 32);
            this.lastFirstMiddleButton.TabIndex = 4;
            this.lastFirstMiddleButton.Text = "Doe, John A";
            this.lastFirstMiddleButton.UseVisualStyleBackColor = true;
            this.lastFirstMiddleButton.Click += new System.EventHandler(this.lastFirstMiddleButton_Click);
            // 
            // lastFirstButton
            // 
            this.lastFirstButton.Location = new System.Drawing.Point(221, 150);
            this.lastFirstButton.Name = "lastFirstButton";
            this.lastFirstButton.Size = new System.Drawing.Size(154, 33);
            this.lastFirstButton.TabIndex = 5;
            this.lastFirstButton.Text = "Doe, John";
            this.lastFirstButton.UseVisualStyleBackColor = true;
            this.lastFirstButton.Click += new System.EventHandler(this.lastFirstButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(279, 545);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(95, 33);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(154, 545);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(95, 33);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 612);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button lastFirstButton;
        private System.Windows.Forms.Button lastFirstMiddleButton;
        private System.Windows.Forms.Button lastFirstMiddleTitleButton;
        private System.Windows.Forms.Button firstLastButton;
        private System.Windows.Forms.Button firstMiddleLastButton;
        private System.Windows.Forms.Button titleFirstMiddleLastButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

