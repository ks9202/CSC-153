﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_KaylaSmith
{
    /**
    * 2/19/2023
    * CSC 153
    * Kayla Smith
    * A simple game that takes a user's input of pennies, nickels, dimes, and
    * quarters, displaying whether that number is greater than, less than, or
    * equal to one dollar.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears all text boxes.
            penniesTextBox.Clear();
            nickelsTextBox.Clear();
            dimesTextBox.Clear();
            quartersTextBox.Clear();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Variables for user inputs and declared constants
            // for coin values.
            int numPennies = 0, numNickels = 0, numDimes = 0, numQuarters = 0;
            double userAmount;
            const double PENNY = 0.01;
            const double NICKEL = 0.05;
            const double DIME = 0.10;
            const double QUARTER = 0.25;

            try
            {
                // Try catch for user input. Ensures that values entered
                // are integers. If statements are used to ignore if the
                // user leaves a field blank instead of moving to the catch.

                if (!string.IsNullOrEmpty(penniesTextBox.Text))
                {
                    numPennies = int.Parse(penniesTextBox.Text);
                }
                if (!string.IsNullOrEmpty(nickelsTextBox.Text))
                {
                    numNickels = int.Parse(nickelsTextBox.Text);
                }
                if (!string.IsNullOrEmpty(dimesTextBox.Text))
                {
                    numDimes = int.Parse(dimesTextBox.Text);
                }
                if (!string.IsNullOrEmpty(quartersTextBox.Text))
                {
                    numQuarters = int.Parse(quartersTextBox.Text);
                }
            }
            catch
            {
                MessageBox.Show("One or more invalid amounts entered.\n Try again?");
            }

            // Calculates total amount entered by user.
            userAmount = (PENNY * numPennies) + (NICKEL * numNickels) + (DIME * numDimes)
                + (QUARTER * numQuarters);

            // Output structure to tell the user if their amount is less than, greater
            // than, or equal to one dollar.
            if (userAmount == 1.00)
            {
                MessageBox.Show("Congratulations! That is equal to one dollar!");
            }
            else if (userAmount < 1.00)
            {
                MessageBox.Show("Amount is less than one dollar. Try again?");
            }
            else
            {
                MessageBox.Show("Amount is more than one dollar. Try again?");
            }
        }
    }
}
