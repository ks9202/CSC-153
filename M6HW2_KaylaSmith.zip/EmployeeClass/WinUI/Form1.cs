﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeLibrary;

namespace WinUI
{
    /**
    * 5/1/23
    * CSC 153
    * Kayla Smith
    * This form displays one of three employees' information when a button is clicked.
    * Each employee's information is stored in an object.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Employee objects
        Employee susanMeyers = new Employee();
        Employee markJones = new Employee();
        Employee joyRogers = new Employee();

        private void employee1Button_Click(object sender, EventArgs e)
        {
            // Set Susan Meyers information
            susanMeyers.Name = "Susan Meyers";
            susanMeyers.IdNum = "47899";
            susanMeyers.Department = "Accounting";
            susanMeyers.Position = "Vice President";

            // Display
            MessageBox.Show("Employee name: " + susanMeyers.Name +
                            "\nEmployee ID: " + susanMeyers.IdNum +
                            "\nDepartment: " + susanMeyers.Department +
                            "\nPosition: " + susanMeyers.Position);
        }

        private void employee2Button_Click(object sender, EventArgs e)
        {
            // Set Mark Jones information
            markJones.Name = "Mark Jones";
            markJones.IdNum = "39119";
            markJones.Department = "IT";
            markJones.Position = "Programmer";

            // Display
            MessageBox.Show("Employee name: " + markJones.Name +
                            "\nEmployee ID: " + markJones.IdNum +
                            "\nDepartment: " + markJones.Department +
                            "\nPosition: " + markJones.Position);
        }

        private void employee3Button_Click(object sender, EventArgs e)
        {
            // Set Joy Rogers information
            joyRogers.Name = "Joy Rogers";
            joyRogers.IdNum = "81774";
            joyRogers.Department = "Manufacturing";
            joyRogers.Position = "Engineer";

            // Display
            MessageBox.Show("Employee name: " + joyRogers.Name +
                            "\nEmployee ID: " + joyRogers.IdNum +
                            "\nDepartment: " + joyRogers.Department +
                            "\nPosition: " + joyRogers.Position);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit
            this.Close();
        }
    }
}
