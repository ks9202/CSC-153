﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarLibrary;

namespace WinUI
{
    /**
    * 4/30/23
    * CSC 153
    * Kayla Smith
    * This form creates a Car object with buttons to control the car's speed.
    */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Car object
        Car newCar = new Car();

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            // Make and year assigned to newCar
            newCar.Make = "Ford";
            newCar.Year = "2000";

            // Accelerates speed of newCar by 5
            newCar.Accelerate();

            // Output
            MessageBox.Show(newCar.Speed + " MPH");
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            // Make and year assigned to newCar
            newCar.Make = "Ford";
            newCar.Year = "2000";

            // Decreases speed of newCar by 5
            newCar.Brake();

            // Output
            MessageBox.Show(newCar.Speed + " MPH");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exit
            this.Close();
        }
    }
}
