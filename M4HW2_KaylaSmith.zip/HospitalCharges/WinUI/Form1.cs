﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HospitalChargesLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        /**
        * 3/26/2023
        * CSC 153
        * Kayla Smith
        * A form that calculates hospital charges based on a number of days and four other
        * costs entered by the user.
        */
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Variable declaration
            int userDays;
            double medsCost, surgeryCost, labCost, rehabCost;
            double stayCharges, miscCharges, total;

            try
            {
                // Parsing user input
                userDays = int.Parse(daysTextBox.Text);
                medsCost = double.Parse(medsTextBox.Text);
                surgeryCost = double.Parse(surgeryTextBox.Text);
                labCost = double.Parse(labTextBox.Text);
                rehabCost = double.Parse(rehabTextBox.Text);

                // User input passed into methods
                stayCharges = calcCharges.CalcStayCharges(userDays);
                miscCharges = calcCharges.CalcMiscCharges(medsCost, surgeryCost, labCost, rehabCost);
                total = calcCharges.CalcTotalCharges(stayCharges, miscCharges);

                // Output
                MessageBox.Show("Stay Charges: $" + stayCharges +
                                "\nMisc. Charges: $" + miscCharges +
                                "\nTotal Charge: $" + total);
            }
            catch
            {
                // Invalid input
                MessageBox.Show("One or more entries invalid. \nPlease enter valid numbers to calculate.");
            }

            // Clear text boxes
            daysTextBox.Clear();
            medsTextBox.Clear();
            surgeryTextBox.Clear();
            labTextBox.Clear();
            rehabTextBox.Clear();
            daysTextBox.Focus();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears all text boxes.
            daysTextBox.Clear();
            medsTextBox.Clear();
            surgeryTextBox.Clear();
            labTextBox.Clear();
            rehabTextBox.Clear();
            daysTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Exits the form.
            this.Close();
        }
    }
}
