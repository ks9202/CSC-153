﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaLibrary
{
    public static class Area
    {
        public static double CalcArea(double radius, double pi)
        {
            // Circle
            double area = (radius * radius) * pi;
            return area;
        }

        public static double CalcArea(int width, int length)
        {
            // Rectangle
            double area = width * length;
            return area;
        }

        public static double CalcArea(double radius, double height, double pi)
        {
            // Cylinder
            double area = (radius * radius) * pi * height;
            return area;
        }
    }
}
