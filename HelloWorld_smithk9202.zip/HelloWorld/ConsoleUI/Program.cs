﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Kayla Smith");
            Console.WriteLine("I am taking this class to gain experience with C# because I want to try as many languages as possible.");
            Console.WriteLine("I have taken CTI-110 and CIS-115.");
            Console.WriteLine("Most conditionals were covered in my other classes, but not switches.");
            Console.WriteLine("Classes were not covered.");
            Console.ReadLine();
        }
    }
}
