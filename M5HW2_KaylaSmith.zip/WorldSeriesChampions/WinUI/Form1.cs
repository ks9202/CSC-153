﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WorldSeriesLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        /**
        * 4/16/2023
        * CSC 153
        * Kayla Smith
        * This program displays a form with a list of teams that have won the
        * World Series, with team names and world series winners read from text
        * files. When a user selects a team in a list box and clicks the choose
        * button, the number of times that team has won the World Series will be
        * displayed.
        */
        public Form1()
        {
            InitializeComponent();

            // Adds all teams from Teams.txt file into list
            List<string> teamsList = new List<string>(WorldSeries.ReadTeams());
            // Adds teams into list box
            foreach (string team in teamsList)
            {
                teamsListBox.Items.Add(team);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Closes the form
            this.Close();
        }

        private void chooseButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Reads user's team choice into choice, creates winsList, retrieves number
                // of wins and displays to user.
                string choice = teamsListBox.SelectedItem.ToString();
                List<string> winsList = new List<string>(WorldSeries.ReadWins());
                int wins = WorldSeries.ReturnWins(winsList, choice);

                // Corrects grammar for display
                if (wins > 1)
                {
                    MessageBox.Show(wins + " wins.");
                }
                else
                {
                    MessageBox.Show(wins + " win.");
                }
            }
            catch
            {
                // If user doesn't select a team before clicking the choose button
                MessageBox.Show("Please select a team.");
            }
        }
    }
}
