﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter first name => ");

            string firstName = Console.ReadLine();

            Console.WriteLine(firstName);

            Console.Write("Enter age => ");

            switch (Console.ReadLine())
            {
                case "45":
                    Console.WriteLine("Ok");
                    break;
                default:
                    Console.WriteLine("Nope");
                    break;
            }

            Console.ReadLine();
        }
    }
}
