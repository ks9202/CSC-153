﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.employee1Button = new System.Windows.Forms.Button();
            this.employee2Button = new System.Windows.Forms.Button();
            this.employee3Button = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // employee1Button
            // 
            this.employee1Button.Location = new System.Drawing.Point(51, 108);
            this.employee1Button.Name = "employee1Button";
            this.employee1Button.Size = new System.Drawing.Size(178, 126);
            this.employee1Button.TabIndex = 0;
            this.employee1Button.Text = "Employee 1";
            this.employee1Button.UseVisualStyleBackColor = true;
            this.employee1Button.Click += new System.EventHandler(this.employee1Button_Click);
            // 
            // employee2Button
            // 
            this.employee2Button.Location = new System.Drawing.Point(272, 108);
            this.employee2Button.Name = "employee2Button";
            this.employee2Button.Size = new System.Drawing.Size(178, 126);
            this.employee2Button.TabIndex = 1;
            this.employee2Button.Text = "Employee 2";
            this.employee2Button.UseVisualStyleBackColor = true;
            this.employee2Button.Click += new System.EventHandler(this.employee2Button_Click);
            // 
            // employee3Button
            // 
            this.employee3Button.Location = new System.Drawing.Point(493, 108);
            this.employee3Button.Name = "employee3Button";
            this.employee3Button.Size = new System.Drawing.Size(178, 126);
            this.employee3Button.TabIndex = 2;
            this.employee3Button.Text = "Employee 3";
            this.employee3Button.UseVisualStyleBackColor = true;
            this.employee3Button.Click += new System.EventHandler(this.employee3Button_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(306, 292);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(117, 48);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(187, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(363, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Choose an option to display employee information.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 407);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.employee3Button);
            this.Controls.Add(this.employee2Button);
            this.Controls.Add(this.employee1Button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button employee1Button;
        private System.Windows.Forms.Button employee2Button;
        private System.Windows.Forms.Button employee3Button;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
    }
}

